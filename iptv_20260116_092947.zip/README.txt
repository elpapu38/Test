📦 ZIP generado por BOT IPTV.
Incluye: canales.m3u, lista_canales.txt
